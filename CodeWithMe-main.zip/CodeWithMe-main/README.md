# CODEWITHME

# Features:
- Developed an application that provides a Real Time Code Editor, video feature , and whiteboard feature at one place with multiple user access in synchorised way to all.
- Used React.js for good UI
- Used Socket.io for Multi user connections
- MongoDB for Database

